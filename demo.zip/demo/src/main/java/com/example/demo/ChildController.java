package com.example.demo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


@RestController
class ChildController {
    private List<ChildInstallment> childData;

    public ChildController() {
        childData = loadDataFromFile();
    }

    private List<ChildInstallment> loadDataFromFile() {
        try {
            ClassPathResource resource = new ClassPathResource("child.json");
            ObjectMapper mapper = new ObjectMapper();
            ChildDataWrapper dataWrapper = mapper.readValue(resource.getInputStream(), ChildDataWrapper.class);
            return dataWrapper.getData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    @GetMapping("/children")
    public ResponseEntity<List<ChildInstallment>> getChildData() {
        List<ChildInstallment> sortedChildData = childData.stream()
                .sorted(Comparator.comparingInt(ChildInstallment::getId))
                .collect(Collectors.toList());

        return new ResponseEntity<>(sortedChildData, HttpStatus.OK);
    }
}
