package com.example.demo;

public class ChildInstallment {
    private int id;
    private int parentId;
    private int paidAmount;

    public ChildInstallment(int id, int parentId, int paidAmount) {
        this.id = id;
        this.parentId = parentId;
        this.paidAmount = paidAmount;
    }

    public void setId(int id){
        this.id = id;
    }


    public int getId(){
        return this.id;
    }

  public void setParentId(int parentId){
        this.parentId = parentId;
    }


    public int getParentId(){
        return this.parentId;
    }

  public void setPaidAmount(int paidAmount){
        this.paidAmount = paidAmount;
    }


    public int getPaidAmount(){
        return this.paidAmount;
    }

}