package com.example.demo;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@RestController
public class ParentController {
 private static final int PAGE_SIZE = 2;

    private List<ParentTransaction> parentData;

    public ParentController() {
        parentData = loadDataFromFile();
    }

    private List<ParentTransaction> loadDataFromFile() {
        try {
            ClassPathResource resource = new ClassPathResource("parentdata.json");
            ObjectMapper mapper = new ObjectMapper();
            ParentDataWrapper dataWrapper = mapper.readValue(resource.getInputStream(), ParentDataWrapper.class);
            return dataWrapper.getData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ArrayList<>();
    }

    @GetMapping("/parents")
    public ResponseEntity<List<ParentTransaction>> getParentTransactions(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "id") String sortBy
    ) {
        int startIndex = (page - 1) * PAGE_SIZE;
        int endIndex = Math.min(startIndex + PAGE_SIZE, parentData.size());
        List<ParentTransaction> paginatedParents = parentData.subList(startIndex, endIndex);

        // Sort by parent ID
        if (sortBy.equalsIgnoreCase("id")) {
            paginatedParents = paginatedParents.stream()
                    .sorted(Comparator.comparingInt(ParentTransaction::getId))
                    .collect(Collectors.toList());
        }

        return new ResponseEntity<>(paginatedParents, HttpStatus.OK);
    }

}
